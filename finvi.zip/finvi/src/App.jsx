import { useState } from 'react'
import './styles.css'
import HomeScreen        from './screens/HomeScreen.jsx'
import TransactionsScreen from './screens/TransactionsScreen.jsx'
import BudgetsScreen     from './screens/BudgetsScreen.jsx'
import GoalsScreen       from './screens/GoalsScreen.jsx'
import CardsScreen       from './screens/CardsScreen.jsx'
import AddScreen         from './screens/AddScreen.jsx'
import ChatScreen        from './screens/ChatScreen.jsx'

const NAV = [
  { id:'home',         icon:'🏠', label:'Início' },
  { id:'transactions', icon:'📋', label:'Extrato' },
  { id:'add',          icon:'➕', label:'Adicionar', center:true },
  { id:'budgets',      icon:'🎯', label:'Orçamento' },
  { id:'chat',         icon:'💬', label:'Finn IA' },
]

export default function App() {
  const [tab, setTab] = useState('home')

  const navigate = (t) => setTab(t)

  const screens = {
    home:         <HomeScreen onNavigate={navigate} />,
    transactions: <TransactionsScreen />,
    budgets:      <BudgetsScreen />,
    goals:        <GoalsScreen />,
    cards:        <CardsScreen />,
    add:          <AddScreen onNavigate={navigate} />,
    chat:         <ChatScreen />,
  }

  return (
    <div style={{ maxWidth:430, margin:'0 auto', height:'100%', display:'flex', flexDirection:'column', background:'#f5f3ef', position:'relative' }}>

      {/* ── Top header ── */}
      <div style={{ padding:'16px 20px 0', flexShrink:0 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div>
            <p style={{ fontSize:12, color:'#a09990', fontWeight:400 }}>Bom dia,</p>
            <h1 style={{ fontFamily:"'DM Serif Display', serif", fontSize:20, color:'#1a1410', lineHeight:1.2 }}>Ana Silva 👋</h1>
          </div>
          {/* Logo */}
          <div style={{ display:'flex', alignItems:'center', gap:6 }}>
            <div style={{ width:34, height:34, borderRadius:10, background:'linear-gradient(135deg,#c8a882,#8a6a4a)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:18 }}>🦁</div>
            <span style={{ fontFamily:"'DM Serif Display', serif", fontSize:18, color:'#1a1410' }}>FinVi</span>
          </div>
        </div>
      </div>

      {/* ── Screen content ── */}
      <div style={{ flex:1, overflowY:'auto', padding:'16px 20px', paddingBottom: tab==='chat' ? 12 : 90 }}>
        {screens[tab] || screens.home}
      </div>

      {/* ── Bottom Nav ── */}
      <div style={{
        position:'absolute', bottom:0, left:0, right:0,
        background:'rgba(255,255,255,0.96)', backdropFilter:'blur(12px)',
        borderTop:'1px solid #f0ece6',
        display:'flex', justifyContent:'space-around', alignItems:'center',
        padding:'8px 0 20px',
        zIndex:100,
      }}>
        {NAV.map(n => n.center
          ? (
            <button key={n.id} className="nav-btn" onClick={() => navigate(n.id)} style={{ padding:0 }}>
              <div style={{
                width:52, height:52, borderRadius:'50%',
                background: tab===n.id ? '#3d2d1e' : '#1a1410',
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize:24, boxShadow:'0 4px 14px rgba(0,0,0,0.25)',
                transform: tab===n.id ? 'scale(1.08)' : 'scale(1)',
                transition:'transform 0.2s',
              }}>
                {n.icon}
              </div>
            </button>
          ) : (
            <button key={n.id} className={`nav-btn ${tab===n.id?'active':''}`} onClick={() => navigate(n.id)}>
              <span className="nav-icon">{n.icon}</span>
              <span style={{ fontWeight: tab===n.id ? 600 : 400 }}>{n.label}</span>
            </button>
          )
        )}
      </div>
    </div>
  )
}
