import { useState } from 'react'
import { TRANSACTIONS, CATEGORIES } from '../data.js'

export default function TransactionsScreen() {
  const [filter, setFilter] = useState('Todas')
  const [search, setSearch] = useState('')

  const filtered = TRANSACTIONS.filter(t => {
    const matchCat = filter === 'Todas' || t.cat === filter
    const matchSearch = t.desc.toLowerCase().includes(search.toLowerCase())
    return matchCat && matchSearch
  })

  const totalIn  = filtered.filter(t => t.amount > 0).reduce((s,t) => s + t.amount, 0)
  const totalOut = filtered.filter(t => t.amount < 0).reduce((s,t) => s + Math.abs(t.amount), 0)

  return (
    <div className="fade-up">
      <h2 style={{ fontFamily:"'DM Serif Display', serif", fontSize:24, color:'#1a1410', marginBottom:16 }}>Extrato</h2>

      {/* Summary bar */}
      <div style={{ display:'flex', gap:10, marginBottom:14 }}>
        <div className="card" style={{ flex:1, padding:14, textAlign:'center' }}>
          <p style={{ fontSize:11, color:'#a09990', marginBottom:3 }}>Entradas</p>
          <p style={{ fontSize:15, fontWeight:700, color:'#2ECC71' }}>+R$ {totalIn.toFixed(2).replace('.',',')}</p>
        </div>
        <div className="card" style={{ flex:1, padding:14, textAlign:'center' }}>
          <p style={{ fontSize:11, color:'#a09990', marginBottom:3 }}>Saídas</p>
          <p style={{ fontSize:15, fontWeight:700, color:'#e07070' }}>-R$ {totalOut.toFixed(2).replace('.',',')}</p>
        </div>
      </div>

      {/* Search */}
      <input
        className="input-base"
        style={{ marginBottom:12, borderRadius:100 }}
        placeholder="🔍  Buscar transação..."
        value={search}
        onChange={e => setSearch(e.target.value)}
      />

      {/* Category chips */}
      <div style={{ display:'flex', gap:8, overflowX:'auto', paddingBottom:6, marginBottom:14 }}>
        {CATEGORIES.map(c => (
          <span key={c} className={`chip ${filter===c?'active':''}`} onClick={() => setFilter(c)}>
            {c}
          </span>
        ))}
      </div>

      {/* List */}
      <div className="card">
        {filtered.length === 0
          ? <p style={{ color:'#a09990', textAlign:'center', padding:'20px 0', fontStyle:'italic' }}>Nenhuma transação encontrada</p>
          : filtered.map(t => (
            <div key={t.id} className="tx-row">
              <div style={{ width:44, height:44, borderRadius:14, background:`${t.color}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22, flexShrink:0 }}>
                {t.emoji}
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <p style={{ fontSize:14, fontWeight:500, color:'#1a1410' }}>{t.desc}</p>
                <p style={{ fontSize:12, color:'#a09990' }}>{t.cat} · {t.date}</p>
              </div>
              <p style={{ fontSize:15, fontWeight:600, color: t.amount > 0 ? '#2ecc71' : '#1a1410', flexShrink:0 }}>
                {t.amount > 0 ? '+' : ''}R$ {Math.abs(t.amount).toFixed(2).replace('.',',')}
              </p>
            </div>
          ))
        }
      </div>
    </div>
  )
}
