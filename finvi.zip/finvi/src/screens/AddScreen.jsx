import { useState } from 'react'

const CATS = [
  { name:'Alimentação', emoji:'🍔' },
  { name:'Transporte',  emoji:'🚗' },
  { name:'Saúde',       emoji:'💊' },
  { name:'Assinaturas', emoji:'📱' },
  { name:'Contas',      emoji:'🏠' },
  { name:'Lazer',       emoji:'🎉' },
  { name:'Receita',     emoji:'💼' },
  { name:'Outro',       emoji:'📦' },
]

export default function AddScreen({ onNavigate }) {
  const [type, setType] = useState('expense') // expense | income
  const [amount, setAmount] = useState('')
  const [desc, setDesc] = useState('')
  const [cat, setCat] = useState('')
  const [done, setDone] = useState(false)

  const handleSave = () => {
    if (!amount || !desc || !cat) return
    setDone(true)
    setTimeout(() => {
      setDone(false)
      setAmount('')
      setDesc('')
      setCat('')
      onNavigate('home')
    }, 1500)
  }

  if (done) return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'60vh', gap:16 }}>
      <div style={{ fontSize:64 }}>✅</div>
      <p style={{ fontFamily:"'DM Serif Display', serif", fontSize:22, color:'#1a1410' }}>Transação salva!</p>
      <p style={{ fontSize:14, color:'#a09990' }}>Redirecionando...</p>
    </div>
  )

  return (
    <div className="fade-up">
      <h2 style={{ fontFamily:"'DM Serif Display', serif", fontSize:24, color:'#1a1410', marginBottom:20 }}>Nova Transação</h2>

      {/* Type toggle */}
      <div style={{ display:'flex', background:'#f0ece6', borderRadius:16, padding:4, marginBottom:24 }}>
        {[
          { id:'expense', label:'💸 Despesa' },
          { id:'income',  label:'💰 Receita' },
        ].map(t => (
          <button key={t.id} onClick={() => setType(t.id)} style={{
            flex:1, padding:'11px 0', border:'none', borderRadius:13, cursor:'pointer',
            background: type===t.id ? '#1a1410' : 'transparent',
            color: type===t.id ? '#fff' : '#a09990',
            fontFamily:"'DM Sans', sans-serif", fontSize:14, fontWeight:600,
            transition:'all 0.2s',
          }}>{t.label}</button>
        ))}
      </div>

      {/* Amount */}
      <div style={{ textAlign:'center', marginBottom:28 }}>
        <p style={{ fontSize:13, color:'#a09990', marginBottom:8 }}>Valor</p>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
          <span style={{ fontFamily:"'DM Serif Display', serif", fontSize:22, color:'#a09990' }}>R$</span>
          <input
            type="number"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            placeholder="0,00"
            style={{
              border:'none', background:'transparent', outline:'none',
              fontFamily:"'DM Serif Display', serif", fontSize:42, color:'#1a1410',
              width:'180px', textAlign:'center',
            }}
          />
        </div>
        <div style={{ height:2, background: type==='income' ? '#2ECC71' : '#e07070', width:80, margin:'0 auto', borderRadius:2 }} />
      </div>

      {/* Description */}
      <input
        className="input-base"
        placeholder="Descrição (ex: iFood, Salário...)"
        value={desc}
        onChange={e => setDesc(e.target.value)}
        style={{ marginBottom:14 }}
      />

      {/* Category */}
      <p style={{ fontSize:12, color:'#a09990', marginBottom:10 }}>Categoria</p>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:28 }}>
        {CATS.filter(c => type==='income' ? c.name==='Receita' || c.name==='Outro' : c.name !== 'Receita').map(c => (
          <button key={c.name} onClick={() => setCat(c.name)} style={{
            padding:'12px 8px', border:`2px solid ${cat===c.name ? '#1a1410' : '#e8e3dc'}`,
            borderRadius:14, background: cat===c.name ? '#f0ece6' : '#fff',
            cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', gap:4,
            transition:'all 0.15s',
          }}>
            <span style={{ fontSize:22 }}>{c.emoji}</span>
            <span style={{ fontSize:10, color: cat===c.name ? '#1a1410' : '#a09990', fontWeight:500 }}>{c.name}</span>
          </button>
        ))}
      </div>

      <button
        className="btn-primary"
        style={{ width:'100%', opacity: (!amount || !desc || !cat) ? 0.4 : 1 }}
        onClick={handleSave}
        disabled={!amount || !desc || !cat}
      >
        Salvar transação
      </button>
    </div>
  )
}
