import { CARDS, TRANSACTIONS } from '../data.js'

export default function CardsScreen() {
  return (
    <div className="fade-up">
      <h2 style={{ fontFamily:"'DM Serif Display', serif", fontSize:24, color:'#1a1410', marginBottom:16 }}>Meus Cartões</h2>

      <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
        {CARDS.map(c => {
          const pct = (c.used / c.limit) * 100
          const cardTx = TRANSACTIONS.filter(t => t.amount < 0).slice(0, 3)
          return (
            <div key={c.id}>
              {/* Card visual */}
              <div style={{
                background:`linear-gradient(135deg,${c.color} 0%,${c.color}bb 100%)`,
                borderRadius:22, padding:24, color:'#fff', marginBottom:12,
                boxShadow:`0 8px 32px ${c.color}44`,
              }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:24 }}>
                  <span style={{ fontSize:28 }}>{c.emoji}</span>
                  <span style={{ fontSize:14, opacity:0.8, fontWeight:500 }}>{c.bank}</span>
                </div>
                <p style={{ fontSize:13, opacity:0.65, marginBottom:2, letterSpacing:2 }}>•••• •••• •••• {c.last4}</p>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:16 }}>
                  <div>
                    <p style={{ fontSize:11, opacity:0.6, marginBottom:2 }}>Fatura atual</p>
                    <p style={{ fontFamily:"'DM Serif Display', serif", fontSize:24 }}>R$ {c.used.toLocaleString('pt-BR',{minimumFractionDigits:2})}</p>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <p style={{ fontSize:11, opacity:0.6, marginBottom:2 }}>Limite</p>
                    <p style={{ fontSize:14, fontWeight:600 }}>R$ {c.limit.toLocaleString('pt-BR')}</p>
                  </div>
                </div>
                <div style={{ marginTop:14, background:'rgba(255,255,255,0.25)', borderRadius:100, height:5 }}>
                  <div style={{ width:`${pct}%`, height:'100%', background:'#fff', borderRadius:100 }} />
                </div>
                <p style={{ fontSize:11, opacity:0.6, marginTop:6 }}>{pct.toFixed(0)}% do limite utilizado</p>
              </div>

              {/* Recent charges */}
              <div className="card" style={{ padding:16 }}>
                <p style={{ fontSize:13, fontWeight:600, color:'#6a5a4a', marginBottom:10 }}>LANÇAMENTOS RECENTES</p>
                {cardTx.map(t => (
                  <div key={t.id} className="tx-row">
                    <span style={{ fontSize:20 }}>{t.emoji}</span>
                    <div style={{ flex:1 }}>
                      <p style={{ fontSize:13, fontWeight:500 }}>{t.desc}</p>
                      <p style={{ fontSize:11, color:'#a09990' }}>{t.date}</p>
                    </div>
                    <p style={{ fontSize:13, fontWeight:600, color:'#1a1410' }}>-R$ {Math.abs(t.amount).toFixed(2).replace('.',',')}</p>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
