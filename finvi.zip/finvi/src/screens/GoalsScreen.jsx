import { useState } from 'react'
import { GOALS_DEFAULT } from '../data.js'

export default function GoalsScreen() {
  const [goals, setGoals] = useState(GOALS_DEFAULT)
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ name:'', emoji:'🎯', target:'', saved:'', color:'#3498DB' })

  const addGoal = () => {
    if (!form.name || !form.target) return
    setGoals(prev => [...prev, {
      id: Date.now(),
      name: form.name,
      emoji: form.emoji,
      target: parseFloat(form.target),
      saved: parseFloat(form.saved) || 0,
      color: form.color,
    }])
    setForm({ name:'', emoji:'🎯', target:'', saved:'', color:'#3498DB' })
    setShowAdd(false)
  }

  const removeGoal = (id) => setGoals(prev => prev.filter(g => g.id !== id))

  const COLORS = ['#3498DB','#2ECC71','#9B59B6','#E74C3C','#F39C12','#1ABC9C']
  const EMOJIS = ['🎯','✈️','🏠','🚗','💻','📱','🎓','👶','💍','🌴','🛡️','💰']

  return (
    <div className="fade-up">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
        <h2 style={{ fontFamily:"'DM Serif Display', serif", fontSize:24, color:'#1a1410' }}>Minhas Metas</h2>
        <button className="btn-primary" style={{ padding:'10px 18px', fontSize:13, borderRadius:100 }} onClick={() => setShowAdd(true)}>
          + Nova meta
        </button>
      </div>

      {/* Total saved */}
      <div className="card" style={{ marginBottom:14, background:'linear-gradient(135deg,#1a1410,#3d2d1e)', color:'#f5f3ef' }}>
        <p style={{ fontSize:11, color:'#8a7a6a', marginBottom:4, letterSpacing:1, textTransform:'uppercase' }}>Total Guardado</p>
        <p style={{ fontFamily:"'DM Serif Display', serif", fontSize:28 }}>
          R$ {goals.reduce((s,g) => s + g.saved, 0).toLocaleString('pt-BR',{minimumFractionDigits:2})}
        </p>
        <p style={{ fontSize:12, color:'#7a6a5a', marginTop:4 }}>em {goals.length} metas ativas</p>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
        {goals.map(g => {
          const pct = Math.min((g.saved / g.target) * 100, 100)
          const remaining = g.target - g.saved
          return (
            <div key={g.id} className="card">
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:12 }}>
                <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                  <div style={{ width:48, height:48, borderRadius:15, background:`${g.color}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:24 }}>
                    {g.emoji}
                  </div>
                  <div>
                    <p style={{ fontSize:15, fontWeight:600, color:'#1a1410' }}>{g.name}</p>
                    <p style={{ fontSize:12, color:'#a09990' }}>
                      R$ {g.saved.toLocaleString('pt-BR',{minimumFractionDigits:2})} / R$ {g.target.toLocaleString('pt-BR',{minimumFractionDigits:2})}
                    </p>
                  </div>
                </div>
                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{ fontFamily:"'DM Serif Display', serif", fontSize:20, color: g.color }}>{pct.toFixed(0)}%</span>
                  <button onClick={() => removeGoal(g.id)} style={{ background:'transparent', border:'none', cursor:'pointer', fontSize:14, opacity:0.3 }}>✕</button>
                </div>
              </div>
              <div className="progress-track">
                <div className="progress-fill" style={{ width:`${pct}%`, background: g.color }} />
              </div>
              {pct < 100
                ? <p style={{ fontSize:12, color:'#a09990', marginTop:8 }}>Faltam R$ {remaining.toLocaleString('pt-BR',{minimumFractionDigits:2})} para a meta 🎯</p>
                : <p style={{ fontSize:12, color:'#2ECC71', marginTop:8 }}>✅ Meta alcançada! Parabéns!</p>
              }
            </div>
          )
        })}
      </div>

      {/* Add modal */}
      {showAdd && (
        <div className="modal-overlay" onClick={() => setShowAdd(false)}>
          <div className="modal-sheet" onClick={e => e.stopPropagation()}>
            <h3 style={{ fontSize:18, fontWeight:700, color:'#1a1410', marginBottom:20 }}>Nova Meta</h3>

            {/* Emoji picker */}
            <p style={{ fontSize:12, color:'#a09990', marginBottom:8 }}>Escolha um ícone</p>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:16 }}>
              {EMOJIS.map(e => (
                <button key={e} onClick={() => setForm(f => ({...f, emoji:e}))} style={{
                  width:40, height:40, borderRadius:12, border:`2px solid ${form.emoji===e ? '#1a1410' : '#e8e3dc'}`,
                  background: form.emoji===e ? '#f0ece6' : '#fff', fontSize:20, cursor:'pointer'
                }}>{e}</button>
              ))}
            </div>

            <input className="input-base" placeholder="Nome da meta" value={form.name} onChange={e => setForm(f => ({...f, name:e.target.value}))} style={{ marginBottom:10 }} />
            <input className="input-base" placeholder="Valor total (R$)" type="number" value={form.target} onChange={e => setForm(f => ({...f, target:e.target.value}))} style={{ marginBottom:10 }} />
            <input className="input-base" placeholder="Já guardado (R$)" type="number" value={form.saved} onChange={e => setForm(f => ({...f, saved:e.target.value}))} style={{ marginBottom:14 }} />

            {/* Color picker */}
            <p style={{ fontSize:12, color:'#a09990', marginBottom:8 }}>Cor</p>
            <div style={{ display:'flex', gap:8, marginBottom:20 }}>
              {COLORS.map(c => (
                <button key={c} onClick={() => setForm(f => ({...f, color:c}))} style={{
                  width:32, height:32, borderRadius:'50%', background:c, border:`3px solid ${form.color===c ? '#1a1410' : 'transparent'}`, cursor:'pointer'
                }} />
              ))}
            </div>

            <div style={{ display:'flex', gap:10 }}>
              <button className="btn-ghost" style={{ flex:1 }} onClick={() => setShowAdd(false)}>Cancelar</button>
              <button className="btn-primary" style={{ flex:1 }} onClick={addGoal}>Criar Meta</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
