import { useState } from 'react'
import { TRANSACTIONS, SUMMARY, CARDS } from '../data.js'

const INSIGHTS = [
  { icon:"⚠️", text:"Seus gastos com alimentação estão 67% do orçamento. Você ainda tem R$197,70 disponíveis.", bg:"#FFF3E0", border:"#FFB74D" },
  { icon:"✨", text:"Você economizou R$340 comparado ao mês anterior. Excelente!", bg:"#E8F5E9", border:"#66BB6A" },
  { icon:"🔔", text:"Netflix e Spotify vencem em 3 dias. Total a pagar: R$61,80.", bg:"#EDE7F6", border:"#9575CD" },
]

export default function HomeScreen({ onNavigate }) {
  const [balanceVisible, setBalanceVisible] = useState(true)
  const recent = TRANSACTIONS.filter(t => t.month === 'abril').slice(0, 5)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

      {/* ── Balance Card ── */}
      <div className="card fade-up" style={{
        background:'linear-gradient(135deg,#1a1410 0%,#3d2d1e 100%)',
        color:'#f5f3ef', padding:24, position:'relative', overflow:'hidden',
        animationDelay:'0s'
      }}>
        <div style={{ position:'absolute', top:-40, right:-40, width:140, height:140, borderRadius:'50%', background:'rgba(255,255,255,0.03)' }} />
        <div style={{ position:'absolute', bottom:-20, left:20, width:90, height:90, borderRadius:'50%', background:'rgba(255,255,255,0.025)' }} />

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6 }}>
          <p style={{ fontSize:11, color:'#8a7a6a', letterSpacing:1.2, textTransform:'uppercase', fontWeight:500 }}>Saldo Total</p>
          <button onClick={() => setBalanceVisible(v => !v)} style={{ background:'transparent', border:'none', cursor:'pointer', fontSize:15, opacity:0.5, color:'#fff', padding:0 }}>
            {balanceVisible ? '🙈' : '👁️'}
          </button>
        </div>

        <h2 style={{ fontFamily:"'DM Serif Display', serif", fontSize:36, letterSpacing:-1, marginBottom:4 }}>
          {balanceVisible
            ? `R$ ${SUMMARY.balance.toLocaleString('pt-BR',{minimumFractionDigits:2})}`
            : 'R$ ••••••'}
        </h2>
        <p style={{ fontSize:12, color:'#5a9a5a', marginBottom:20 }}>↑ R$ 340,00 em relação ao mês passado</p>

        <div style={{ display:'flex', gap:10 }}>
          {[
            { label:'Receitas', value:`+R$ ${SUMMARY.income.toLocaleString('pt-BR',{minimumFractionDigits:2})}`, color:'#7ec87e' },
            { label:'Despesas', value:`-R$ ${SUMMARY.expenses.toLocaleString('pt-BR',{minimumFractionDigits:2})}`, color:'#e07a7a' },
          ].map(s => (
            <div key={s.label} style={{ flex:1, background:'rgba(255,255,255,0.07)', borderRadius:14, padding:'12px 14px' }}>
              <p style={{ fontSize:11, color:'#7a6a5a', marginBottom:5 }}>{s.label}</p>
              <p style={{ fontSize:15, fontWeight:600, color:s.color }}>{s.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Quick Actions ── */}
      <div className="fade-up" style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10, animationDelay:'0.05s' }}>
        {[
          { icon:'➕', label:'Adicionar', tab:'add' },
          { icon:'📊', label:'Relatório', tab:'budgets' },
          { icon:'🎯', label:'Metas', tab:'goals' },
          { icon:'💳', label:'Cartões', tab:'cards' },
        ].map(a => (
          <button key={a.label} onClick={() => onNavigate(a.tab)} style={{
            background:'#fff', border:'none', borderRadius:18, padding:'14px 8px',
            display:'flex', flexDirection:'column', alignItems:'center', gap:6,
            cursor:'pointer', boxShadow:'0 1px 3px rgba(0,0,0,0.06)',
            transition:'transform 0.15s, box-shadow 0.15s',
          }}
            onMouseDown={e => e.currentTarget.style.transform='scale(0.96)'}
            onMouseUp={e => e.currentTarget.style.transform='scale(1)'}
          >
            <span style={{ fontSize:24 }}>{a.icon}</span>
            <span style={{ fontSize:11, color:'#6a5a4a', fontWeight:500 }}>{a.label}</span>
          </button>
        ))}
      </div>

      {/* ── Cards Preview ── */}
      <div className="fade-up" style={{ animationDelay:'0.08s' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
          <h3 style={{ fontSize:14, fontWeight:600, color:'#6a5a4a', letterSpacing:0.3 }}>CARTÕES</h3>
          <button onClick={() => onNavigate('cards')} style={{ fontSize:12, color:'#c8a882', background:'none', border:'none', cursor:'pointer', fontWeight:500 }}>Ver todos</button>
        </div>
        <div style={{ display:'flex', gap:10, overflowX:'auto', paddingBottom:4 }}>
          {CARDS.map(c => (
            <div key={c.id} style={{
              minWidth:160, background:`linear-gradient(135deg,${c.color},${c.color}99)`,
              borderRadius:18, padding:16, color:'#fff', flexShrink:0,
            }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:12 }}>
                <span style={{ fontSize:20 }}>{c.emoji}</span>
                <span style={{ fontSize:11, opacity:0.7 }}>••{c.last4}</span>
              </div>
              <p style={{ fontSize:11, opacity:0.7, marginBottom:2 }}>{c.bank}</p>
              <p style={{ fontSize:15, fontWeight:700 }}>R$ {c.used.toLocaleString('pt-BR',{minimumFractionDigits:2})}</p>
              <div style={{ marginTop:8, background:'rgba(255,255,255,0.2)', borderRadius:100, height:4 }}>
                <div style={{ width:`${(c.used/c.limit)*100}%`, height:'100%', background:'#fff', borderRadius:100 }} />
              </div>
              <p style={{ fontSize:10, opacity:0.6, marginTop:4 }}>de R${c.limit.toLocaleString('pt-BR')}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Insights ── */}
      <div className="fade-up" style={{ animationDelay:'0.1s' }}>
        <h3 style={{ fontSize:14, fontWeight:600, color:'#6a5a4a', letterSpacing:0.3, marginBottom:10 }}>INSIGHTS DO FINN</h3>
        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          {INSIGHTS.map((ins, i) => (
            <div key={i} style={{ background:ins.bg, border:`1px solid ${ins.border}`, borderRadius:14, padding:'12px 14px', display:'flex', gap:10, alignItems:'flex-start' }}>
              <span style={{ fontSize:18, flexShrink:0 }}>{ins.icon}</span>
              <p style={{ fontSize:13, color:'#1a1410', lineHeight:1.55 }}>{ins.text}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Recent Transactions ── */}
      <div className="card fade-up" style={{ animationDelay:'0.12s' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
          <h3 style={{ fontSize:15, fontWeight:600, color:'#1a1410' }}>Transações Recentes</h3>
          <button onClick={() => onNavigate('transactions')} style={{ fontSize:12, color:'#c8a882', background:'none', border:'none', cursor:'pointer', fontWeight:500 }}>Ver todas</button>
        </div>
        {recent.map(t => (
          <div key={t.id} className="tx-row">
            <div style={{ width:42, height:42, borderRadius:13, background:`${t.color}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0 }}>
              {t.emoji}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <p style={{ fontSize:14, fontWeight:500, color:'#1a1410' }}>{t.desc}</p>
              <p style={{ fontSize:12, color:'#a09990' }}>{t.date}</p>
            </div>
            <p style={{ fontSize:15, fontWeight:600, color: t.amount > 0 ? '#2ecc71' : '#1a1410', flexShrink:0 }}>
              {t.amount > 0 ? '+' : ''}R$ {Math.abs(t.amount).toFixed(2).replace('.',',')}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
