// ─── Transactions ─────────────────────────────────────────────────────────────
export const TRANSACTIONS = [
  { id:1,  desc:"iFood",      cat:"Alimentação",  emoji:"🍔", amount:-89.90,   date:"Hoje, 12:34",   color:"#FF6B35", month:"abril" },
  { id:2,  desc:"Salário",    cat:"Receita",       emoji:"💼", amount:5200.00,  date:"Hoje, 09:00",   color:"#2ECC71", month:"abril" },
  { id:3,  desc:"Netflix",    cat:"Assinaturas",   emoji:"🎬", amount:-39.90,   date:"Ontem, 00:00",  color:"#E50914", month:"abril" },
  { id:4,  desc:"Uber",       cat:"Transporte",    emoji:"🚗", amount:-27.50,   date:"Ontem, 18:22",  color:"#333",    month:"abril" },
  { id:5,  desc:"Mercado",    cat:"Alimentação",   emoji:"🛒", amount:-312.40,  date:"Seg, 10:15",    color:"#FF6B35", month:"abril" },
  { id:6,  desc:"Spotify",    cat:"Assinaturas",   emoji:"🎵", amount:-21.90,   date:"Dom, 00:00",    color:"#1DB954", month:"abril" },
  { id:7,  desc:"Academia",   cat:"Saúde",         emoji:"💪", amount:-99.90,   date:"Sáb, 08:00",    color:"#9B59B6", month:"abril" },
  { id:8,  desc:"Freelance",  cat:"Receita",       emoji:"💻", amount:800.00,   date:"Sex, 14:30",    color:"#2ECC71", month:"abril" },
  { id:9,  desc:"Farmácia",   cat:"Saúde",         emoji:"💊", amount:-47.80,   date:"Sex, 11:00",    color:"#9B59B6", month:"abril" },
  { id:10, desc:"Luz",        cat:"Contas",        emoji:"💡", amount:-198.50,  date:"Qui, 09:00",    color:"#F39C12", month:"abril" },
  { id:11, desc:"Aluguel",    cat:"Contas",        emoji:"🏠", amount:-1500.00, date:"01/abr, 10:00", color:"#F39C12", month:"abril" },
  { id:12, desc:"Restaurante",cat:"Alimentação",   emoji:"🍽️", amount:-78.00,   date:"29/mar, 20:00", color:"#FF6B35", month:"março" },
  { id:13, desc:"Salário",    cat:"Receita",       emoji:"💼", amount:5200.00,  date:"01/mar, 09:00", color:"#2ECC71", month:"março" },
  { id:14, desc:"Plano Cel",  cat:"Contas",        emoji:"📱", amount:-59.90,   date:"05/mar, 00:00", color:"#F39C12", month:"março" },
  { id:15, desc:"Cinema",     cat:"Lazer",         emoji:"🎥", amount:-45.00,   date:"15/mar, 19:30", color:"#3498DB", month:"março" },
];

// ─── Budgets ──────────────────────────────────────────────────────────────────
export const BUDGETS_DEFAULT = [
  { cat:"Alimentação", emoji:"🍔", spent:402.30, limit:600,  color:"#FF6B35" },
  { cat:"Transporte",  emoji:"🚗", spent:127.50, limit:200,  color:"#3498DB" },
  { cat:"Assinaturas", emoji:"📱", spent:61.80,  limit:100,  color:"#9B59B6" },
  { cat:"Saúde",       emoji:"💊", spent:147.70, limit:300,  color:"#2ECC71" },
  { cat:"Contas",      emoji:"🏠", spent:198.50, limit:400,  color:"#F39C12" },
  { cat:"Lazer",       emoji:"🎉", spent:45.00,  limit:200,  color:"#3498DB" },
];

// ─── Goals ────────────────────────────────────────────────────────────────────
export const GOALS_DEFAULT = [
  { id:1, name:"Viagem para Europa",  emoji:"✈️",  target:15000, saved:4200,  color:"#3498DB" },
  { id:2, name:"Reserva de emergência",emoji:"🛡️", target:18000, saved:12000, color:"#2ECC71" },
  { id:3, name:"Notebook novo",       emoji:"💻",  target:4500,  saved:1800,  color:"#9B59B6" },
];

// ─── Summary ──────────────────────────────────────────────────────────────────
export const SUMMARY = {
  balance: 5162.20,
  income:  6000.00,
  expenses: 837.80,
  lastMonthExpenses: 1177.80,
};

// ─── Cards ────────────────────────────────────────────────────────────────────
export const CARDS = [
  { id:1, bank:"Nubank",   last4:"4523", limit:8000,  used:1247.30, color:"#820AD1", emoji:"💜" },
  { id:2, bank:"Itaú",     last4:"7891", limit:5000,  used:398.50,  color:"#EC7000", emoji:"🧡" },
  { id:3, bank:"Bradesco", last4:"2234", limit:3000,  used:89.90,   color:"#CC0000", emoji:"❤️" },
];

// ─── Categories ───────────────────────────────────────────────────────────────
export const CATEGORIES = ["Todas","Receita","Alimentação","Transporte","Assinaturas","Saúde","Contas","Lazer"];

// ─── AI System Prompt ─────────────────────────────────────────────────────────
export const SYSTEM_PROMPT = `Você é o Finn, assistente de IA do FinVi, um app de gestão financeira pessoal.
Você é inteligente, simpático e direto — como um amigo que entende muito de finanças.

DADOS FINANCEIROS DO USUÁRIO (Abril 2026):
Receitas: R$6.000,00 (Salário R$5.200 + Freelance R$800)
Despesas: R$837,80
Saldo disponível: R$5.162,20
Variação vs mês anterior: -30% nos gastos (economizou R$340)

TRANSAÇÕES RECENTES:
• iFood: -R$89,90 (Alimentação)
• Netflix: -R$39,90 (Assinaturas)
• Uber: -R$27,50 (Transporte)
• Mercado: -R$312,40 (Alimentação — maior gasto individual)
• Spotify: -R$21,90 (Assinaturas)
• Academia: -R$99,90 (Saúde)
• Farmácia: -R$47,80 (Saúde)
• Luz: -R$198,50 (Contas)
• Aluguel: -R$1.500,00 (Contas)

ORÇAMENTOS ABRIL:
• Alimentação: R$402,30 / R$600 (67%)
• Transporte: R$127,50 / R$200 (64%)
• Assinaturas: R$61,80 / R$100 (62%)
• Saúde: R$147,70 / R$300 (49%)
• Contas: R$198,50 / R$400 (50%)

METAS:
• Viagem Europa: R$4.200 / R$15.000 (28%)
• Reserva emergência: R$12.000 / R$18.000 (67%)
• Notebook: R$1.800 / R$4.500 (40%)

CARTÕES:
• Nubank: usado R$1.247,30 de R$8.000
• Itaú: usado R$398,50 de R$5.000
• Bradesco: usado R$89,90 de R$3.000

Responda SEMPRE em português, de forma natural, calorosa e concisa.
Máximo 3 frases curtas. Seja específico com os dados reais.
Nunca use listas com bullets. Converse como um amigo.`;
